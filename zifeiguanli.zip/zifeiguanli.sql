/*
Navicat MySQL Data Transfer

Source Server         : mysql57
Source Server Version : 50732
Source Host           : 127.0.0.1:3306
Source Database       : zifeiguanli

Target Server Type    : MYSQL
Target Server Version : 50732
File Encoding         : 65001

Date: 2021-01-11 12:43:43
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for t_cart
-- ----------------------------
DROP TABLE IF EXISTS `t_cart`;
CREATE TABLE `t_cart` (
  `userId` varchar(11) CHARACTER SET utf8 NOT NULL,
  `id` int(11) NOT NULL COMMENT '主键',
  `name` varchar(255) DEFAULT NULL COMMENT '商品名称',
  `count` int(11) DEFAULT NULL COMMENT '购买数量',
  `price` double DEFAULT NULL COMMENT '商品单价',
  `totalprice` double DEFAULT NULL COMMENT '消费金额',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of t_cart
-- ----------------------------

-- ----------------------------
-- Table structure for t_cost
-- ----------------------------
DROP TABLE IF EXISTS `t_cost`;
CREATE TABLE `t_cost` (
  `userId` varchar(11) NOT NULL,
  `month` varchar(2) NOT NULL,
  `costprice` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_cost
-- ----------------------------
INSERT INTO `t_cost` VALUES ('root', '1', '128');
INSERT INTO `t_cost` VALUES ('root', '2', '128');
INSERT INTO `t_cost` VALUES ('root', '3', '128');
INSERT INTO `t_cost` VALUES ('root', '4', '128');
INSERT INTO `t_cost` VALUES ('root', '5', '128');
INSERT INTO `t_cost` VALUES ('root', '6', '128');
INSERT INTO `t_cost` VALUES ('root', '7', '128');
INSERT INTO `t_cost` VALUES ('admin', '1', '128');
INSERT INTO `t_cost` VALUES ('admin', '2', '128');

-- ----------------------------
-- Table structure for t_goods
-- ----------------------------
DROP TABLE IF EXISTS `t_goods`;
CREATE TABLE `t_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '商品id',
  `name` varchar(255) DEFAULT NULL COMMENT '商品名称',
  `price` double DEFAULT NULL COMMENT '商品价格',
  `sales` int(11) DEFAULT NULL COMMENT '商品销量',
  `stock` int(11) DEFAULT NULL COMMENT '商品库存',
  `category` varchar(255) DEFAULT NULL COMMENT '商品分类',
  `location` varchar(255) DEFAULT NULL COMMENT '商品产地',
  `imagePath` varchar(255) DEFAULT NULL COMMENT '图片路径',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of t_goods
-- ----------------------------
INSERT INTO `t_goods` VALUES ('2', '5G智享套餐128', '128', '87', '9998', '套餐', '武汉', 'img/com.png');
INSERT INTO `t_goods` VALUES ('3', '5G智享套餐158', '158', '38', '9996', '套餐', '广州', 'img/com.png');
INSERT INTO `t_goods` VALUES ('4', '5G智享套餐198', '198', '522', '478', '套餐', '广州', 'img/com.png');
INSERT INTO `t_goods` VALUES ('5', '5G智享套餐238', '238', '33', '9996', '套餐', '北京', 'img/com.png');
INSERT INTO `t_goods` VALUES ('6', '5G智享套餐298', '298', '1507', '9995', '套餐', '北京', 'img/com.png');
INSERT INTO `t_goods` VALUES ('7', '5G智享套餐398', '398', '111', '9995', '套餐', '广州', 'img/com.png');
INSERT INTO `t_goods` VALUES ('13', '彩铃', '5', '103', '9996', '增值业务', '北京', 'img/com.png');
INSERT INTO `t_goods` VALUES ('14', '高清视频通话', '10', '101', '998', '增值业务', '深圳', 'img/com.png');
INSERT INTO `t_goods` VALUES ('15', '短信', '5', null, '9999', '增值业务', '北京', '123');

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `taocanId` varchar(11) NOT NULL,
  PRIMARY KEY (`username`,`taocanId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('admin', 'admin', 'aa', '男', '0', '上海', '2');
INSERT INTO `t_user` VALUES ('root', 'root', 'root', '男', '18', '北京', '2');
INSERT INTO `t_user` VALUES ('u0001', '123', 'tom', '女', '19', '山东', '2');
INSERT INTO `t_user` VALUES ('u0002', '123456', 'zs', '女', '0', '太原', '2');
