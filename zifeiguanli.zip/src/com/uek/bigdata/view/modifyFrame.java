package com.uek.bigdata.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import com.uek.bigdata.daomain.Goods;
import com.uek.bigdata.daomain.User;
import com.uek.bigdata.service.IGoodService;
import com.uek.bigdata.service.IUserService;
import com.uek.bigdata.service.impl.GoodServiceImpl;
import com.uek.bigdata.service.impl.UserServiceImpl;
import com.uek.bigdata.util.FrameUtils;

public class modifyFrame extends PublicFrame{
	 private modifyFrame modifyFrame;
	    private JTextField pfPassword;    //定义输入密码框
	    private JTextField pfRePassword;    //定义确认密码框
	    private JTextField pfName;    //定义输入姓名框
	    private JTextField pfStock;
	    private JTextField pfCategory;
	    private JComboBox<String> pfLocation;
	    private JComboBox<String> pfsort;
	    private JTextField pfPath;
	    private static User user = null;
	    private JTextField pfsals;
	    
	    private JButton btExit;
	    private JLabel lblName;
	    private JButton btSave;            //定义保存按钮
	    private JButton btBack;                //定义返回按钮
	    private JLabel lblQuantity;
	    IGoodService goodService = new GoodServiceImpl();
	    modifyFrame(int id){
	        this.setLayout(null);       //绝对布局
	        setTitle("--修改套餐--");  //界面标题
	        setBounds(100, 100, 750, 500);//设置界面位置大小
	        setResizable(false);//设置界面大小不可改变
	        setLocationRelativeTo(null);        //设置登录界面居中
	        getContentPane().setLayout(null);   //设置绝对布局
	        modifyFrame = this;
	        this.user = user;
	        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); //设置默认关闭操作

	        JLabel jlName = new JLabel("名 称");   //定义密码文本标签
	        jlName.setBounds(20, 62, 74, 15); //设置标签位置
	        this.add(jlName); //添加到本界面

	        pfName = new JTextField();    //定义密码1 输入框
	        pfName.setBounds(104, 62, 148, 25);//设置输入框位置
	        this.add(pfName);  //添加到本界面

	        JLabel jlPass = new JLabel("价 格");   //定义密码文本标签
	        jlPass.setBounds(20, 102, 74, 15); //设置标签位置
	        this.add(jlPass); //添加到本界面

	        pfPassword = new JTextField();    //定义密码1 输入框
	        pfPassword.setBounds(104, 102, 148, 25);//设置输入框位置
	        this.add(pfPassword);  //添加到本界面

	        JLabel jlStock = new JLabel("库 存");   //定义密码文本标签
	        jlStock.setBounds(20, 142, 74, 15); //设置标签位置
	        this.add(jlStock); //添加到本界面

	        pfStock = new JTextField();    //定义密码1 输入框
	        pfStock.setBounds(104, 142, 148, 25);//设置输入框位置
	        this.add(pfStock);  //添加到本界面

	        JLabel jlCategory = new JLabel("类 别");   //定义密码文本标签
	        jlCategory.setBounds(20, 182, 74, 15); //设置标签位置
	        this.add(jlCategory); //添加到本界面
	        
	        pfsort = new JComboBox<String>(); //定义一个城市选择框
	        pfsort.setModel(new DefaultComboBoxModel<String>(new String[]{
	                "套餐", "增值业务"}));
	        pfsort.setBounds(104, 182, 148, 25);//设置位置
	        this.add(pfsort); //添加到本界面中

//	        pfCategory = new JTextField();    //定义密码1 输入框
//	        pfCategory.setBounds(104, 182, 148, 25);//设置输入框位置
//	        this.add(pfCategory);  //添加到本界面

	        JLabel jlLocation = new JLabel("归属地");   //定义密码文本标签
	        jlLocation.setBounds(20, 222, 74, 15); //设置标签位置
	        this.add(jlLocation); //添加到本界面

	        pfLocation = new JComboBox<String>(); //定义一个城市选择框
	        pfLocation.setModel(new DefaultComboBoxModel<String>(new String[]{
	                "北京", "上海", "广州", "太原", "西安", "武汉"}));
	        pfLocation.setBounds(105, 218, 148, 25);//设置位置
	        this.add(pfLocation); //添加到本界面中

	        JLabel jlPath = new JLabel("路 径");   //定义密码文本标签
	        jlPath.setBounds(20, 262, 74, 15); //设置标签位置
	        this.add(jlPath); //添加到本界面

	        pfPath = new JTextField();    //定义密码1 输入框
	        pfPath.setBounds(104, 262, 148, 25);//设置输入框位置
	        this.add(pfPath);  //添加到本界面
	        
	        JLabel jsales = new JLabel("销 量");   //定义密码文本标签
	        jsales.setBounds(20, 302, 74, 15); //设置标签位置
	        this.add(jsales); //添加到本界面

	        pfsals = new JTextField();    //定义密码1 输入框
	        pfsals.setBounds(104, 302, 148, 25);//设置输入框位置
	        this.add(pfsals);  //添加到本界面

	      //  pfRePassword = new JPasswordField();    //定义一个密码2输入框
	     //   pfRePassword.setBounds(104, 302, 148, 25);//密码输入框位置
	      //  this.add(pfRePassword); //添加到本界面
	        btSave = new JButton("确 认");   //注册按钮
	        btSave.setBounds(13, 342, 90, 35);//设置位置
	        btSave.addActionListener(new ActionListener() {    //添加监听事件
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	confirmGood(id);
	            }
	        });
	        this.add(btSave);//将注册按钮添加到界面

	        btExit = new JButton("返 回");
	        btExit.setBounds(143, 342, 90, 35);
	        add(btExit);
	        btExit.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                dispose();
	              //  FrameUtils.browse.refresh();        //缓存界面刷新
	            }
	        });

	        setTitle("添加套餐");
	        setSize(300, 464);    //设置界面大小
	        setResizable(false);                //设置界面大小不可改变
	        setLocationRelativeTo(null);        //设置登录界面居中
	        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);   //设置默认关闭操作
	    }
	    public void confirmGood(int id){
	    	double price1;
	    	int stock;
	    	int sales;
	        String PName = pfName.getText().trim();
	        if("".equals(PName)){
	            JOptionPane.showMessageDialog(this, "名称不能为空！");//提示
	        }
	        String price = pfPassword.getText().trim();
	        if("".equals(price)) {
	        	price1 = 0;
	        	 JOptionPane.showMessageDialog(this, "价格不能为空！");//提示
	        }else {
	        	price1 = Double.parseDouble(price);
	        }
	        String saleString = pfsals.getText().trim();
	        if("".equals(saleString)) {
	        	sales = 0;
	        }else {
	        	sales = Integer.valueOf(saleString);
	        }
	        String stockString = pfStock.getText().trim();
	        
	        if("".equals(stockString)) {
	        	stock = 0;
	        	JOptionPane.showMessageDialog(this, "库存不能为空！");//提示
	        }else {
	        	stock = Integer.parseInt(stockString);
	        }
	        String location = pfLocation.getSelectedItem().toString();
	        String category = pfsort.getSelectedItem().toString();
	        String path = pfPath.getText().trim();
	        if("".equals(location)){
	            JOptionPane.showMessageDialog(this, "位置不能为空！");//提示
	        }else if("".equals(category)){
	            JOptionPane.showMessageDialog(this, "类别不能为空！");//提示
	        }else if("".equals(path)){
	            JOptionPane.showMessageDialog(this, "路径不能为空！");//提示
	        }else{
	            Goods goods = new Goods(id,PName, price1,sales, stock, category, location, path);
	            goodService.modifyGood(goods);
	            
	            JOptionPane.showMessageDialog(this, "修改成功！");//提示
	        }
	    }
}
