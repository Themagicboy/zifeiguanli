package com.uek.bigdata.view;

import com.uek.bigdata.daomain.User;
import com.uek.bigdata.service.IGoodService;
import com.uek.bigdata.service.IUserService;
import com.uek.bigdata.service.impl.GoodServiceImpl;
import com.uek.bigdata.service.impl.UserServiceImpl;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DelProductFrame extends PublicFrame {
    private JTextField tfUsername;         //定义注册用户名
    private JPasswordField pfPassword;    //定义输入密码框
    private JPasswordField pfRePassword;    //定义确认密码框
    private JTextField tfName;
    private JButton btSave;
    private JButton btRegister;            //定义注册按钮
    private JButton btBack;                //定义返回按钮

    private JLabel lblCity, lblSex;         //定义城市和性别
    private JRadioButton rdoMale, rdoFemale;    //定义性别选择
    private JComboBox<String> cboCity;      //定义城市的多选框
    private DelProductFrame delProductFrame;
    IGoodService goodService = new GoodServiceImpl();

    DelProductFrame(User user){
        this.setLayout(null);       //绝对布局
        setTitle("--删除商品--");  //界面标题
        setBounds(100, 100, 750, 500);//设置界面位置大小
        setResizable(false);//设置界面大小不可改变
        setLocationRelativeTo(null);        //设置登录界面居中
        getContentPane().setLayout(null);   //设置绝对布局
        delProductFrame = this;
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); //设置默认关闭操作
        JLabel jlUser = new JLabel("id/名称"); //定义用户名文本标签
        jlUser.setBounds(20, 42, 74, 15);  //设置标签文职
        this.add(jlUser);//添加到本界面

        tfUsername = new JTextField();     //定义一个文本输入框
        tfUsername.setBounds(104, 40, 148, 25);    //设置位置
        this.add(tfUsername);//添加到本界面

        btSave = new JButton("确 认");   //注册按钮
        btSave.setBounds(33, 92, 90, 35);//设置位置
        btSave.addActionListener(new ActionListener() {    //添加监听事件
            @Override
            public void actionPerformed(ActionEvent e) {
                DelProducts();
            }
        });
        this.add(btSave);//将注册按钮添加到界面

        btBack = new JButton("取 消");   //定义一个返回按钮
        btBack.setBounds(160, 92, 90, 35);
        btBack.addActionListener(new ActionListener() {    //返回按钮的监听方法
            @Override
            public void actionPerformed(ActionEvent e) { 	
                dispose(); //关闭界面
                new SuperBrowerFrame(user);
            }
        });
        this.add(btBack); //将返回按钮添加到界面

        setTitle("删除商品");
        setSize(300, 264);    //设置界面大小
        setResizable(false);                //设置界面大小不可改变
        setLocationRelativeTo(null);        //设置登录界面居中
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);   //设置默认关闭操作
    }

    public void DelProducts(){
        String id = tfUsername.getText().trim();
        if("".equals(id)){
            JOptionPane.showMessageDialog(this, "内容不能为空！");//提示
        }else{
            JOptionPane.showMessageDialog(this, "删除成功！");//提示
            goodService.delproductbyid(id);
        }
    }
}
