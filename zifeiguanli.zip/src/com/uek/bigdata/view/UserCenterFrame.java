package com.uek.bigdata.view;

import com.uek.bigdata.daomain.CartItem;
import com.uek.bigdata.daomain.User;
import com.uek.bigdata.service.IUserService;
import com.uek.bigdata.service.impl.UserServiceImpl;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class UserCenterFrame extends PublicFrame{

    private UserCenterFrame userCenterFrame;
    private JPasswordField pfPassword;    //定义输入密码框
    private JPasswordField pfRePassword;    //定义确认密码框
    private JPasswordField pfName;    //定义输入姓名框
    private static User user = null;

    private JLabel lblName;
    private JButton btSave;            //定义保存按钮
    private JButton btBack;                //定义返回按钮
    private JLabel lblQuantity;
    IUserService userService = new UserServiceImpl();

    UserCenterFrame(User user){
        this.setLayout(null);       //绝对布局
        setTitle("--用户中心--");  //界面标题
        setBounds(100, 100, 750, 500);//设置界面位置大小
        setResizable(false);//设置界面大小不可改变
        setLocationRelativeTo(null);        //设置登录界面居中
        getContentPane().setLayout(null);   //设置绝对布局
        userCenterFrame = this;
        this.user = user;
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); //设置默认关闭操作

        lblQuantity = new JLabel("0");
        lblQuantity.setBounds(151, 450, 48, 15);
        add(lblQuantity);

        lblName = new JLabel("您好,在这里修改密码！");   //定义一个姓名标签
        lblName.setBounds(10, 10, 200, 15);//设置位置
        this.add(lblName);//添加到界面中

        initUser();

        JLabel jlName = new JLabel("输入姓名");   //定义密码文本标签
        jlName.setBounds(20, 62, 74, 15); //设置标签位置
        this.add(jlName); //添加到本界面

        pfName = new JPasswordField();    //定义密码1 输入框
        pfName.setBounds(104, 62, 148, 25);//设置输入框位置
        this.add(pfName);  //添加到本界面

        JLabel jlPass = new JLabel("输入密码");   //定义密码文本标签
        jlPass.setBounds(20, 129, 74, 15); //设置标签位置
        this.add(jlPass); //添加到本界面

        pfPassword = new JPasswordField();    //定义密码1 输入框
        pfPassword.setBounds(104, 124, 148, 25);//设置输入框位置
        this.add(pfPassword);  //添加到本界面

        JLabel jlRePass = new JLabel("再次输入密码");//定义密码2标签
        jlRePass.setBounds(20, 186, 74, 15);//设置位置
        this.add(jlRePass);//添加到本界面

        pfRePassword = new JPasswordField();    //定义一个密码2输入框
        pfRePassword.setBounds(104, 182, 148, 25);//密码输入框位置
        this.add(pfRePassword); //添加到本界面
        btSave = new JButton("保 存");   //注册按钮
        btSave.setBounds(33, 330, 90, 35);//设置位置
        btSave.addActionListener(new ActionListener() {    //添加监听事件
            @Override
            public void actionPerformed(ActionEvent e) {
                btModefyPwd(); //注册方法
            }
        });
        this.add(btSave);//将注册按钮添加到界面

        btBack = new JButton("返 回");   //定义一个返回按钮
        btBack.setBounds(160, 330, 90, 35);
        btBack.addActionListener(new ActionListener() {    //返回按钮的监听方法
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); //关闭界面
            }
        });
        this.add(btBack); //将返回按钮添加到界面

        setTitle("修改信息");
        setSize(300, 464);    //设置界面大小
        setResizable(false);                //设置界面大小不可改变
        setLocationRelativeTo(null);        //设置登录界面居中
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);   //设置默认关闭操作
    }

    public void btModefyPwd(){
        String userName = user.getUsername();
        String name = pfName.getText().trim();   //获取输入的姓名
        String pass = new String(pfPassword.getPassword()).trim();   //获取第一次输入的密码
        String rePass = new String(pfRePassword.getPassword()).trim();   //获取第二次输入的密码
        System.out.println(name);
        System.out.println(pass);
        System.out.println(rePass);

        if("".equals(name)){
            name = user.getName();
        }
        if("".equals(pass)||"".equals(rePass)){
            JOptionPane.showMessageDialog(this, "密码不能为空！");//提示
        }
        User user = new User(userName, pass, name);
        if(!pass.equals(rePass)){
            JOptionPane.showMessageDialog(this, "两次密码不一致！");//提示
            //this.setLogin(true);//login状态为true
            //dispose(); //关闭界面
        }else{
            userService.UpdatePwd(user);
            JOptionPane.showMessageDialog(this, "修改成功！");//提示
        }
    }

    private void initUser() {
        if (user == null) {
            return;
        }
        // 显示用户真实姓名 + 欢迎语
        this.lblName.setText(user.getName() + ",您好,在这里修改密码");
    }
}

