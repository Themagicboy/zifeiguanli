package com.uek.bigdata.controller;

import java.util.ArrayList;
import java.util.List;

import com.uek.bigdata.daomain.CartItem;
import com.uek.bigdata.daomain.Cost;
import com.uek.bigdata.daomain.Goods;
import com.uek.bigdata.daomain.User;
import com.uek.bigdata.service.ICostService;
import com.uek.bigdata.service.impl.CostServiceImpl;

public class costAction {
	private ICostService costService = new CostServiceImpl();

	public List<Cost> showAll() {
        List<Cost> goods = costService.findAll();
        //2. 返回结果
        return goods;
    }
	
	public List<Cost> findByUserName(User user) {
        return costService.findByUsername(user);
    }
	
	public List<Cost> queryCost(User user, String name, String category) {

        List<Cost> Cost = new ArrayList<>(); //定义查询列表
        List<Cost> goods = costService.findByUsername(user);
        String goodsName = name;
        if (goodsName == null)      //用户名为空
            goodsName = "";

        List<Cost> costsList = this.showAll();      //获取所有的商品

        	
        
        for (Cost cost : goods) {         //遍历所有商品
            if ((cost.getMonth().contains(goodsName))       //找到符合条件的
                    && (category == null || cost.getMonth().equals(category))       //找到符合条件的
            ) {
            	Cost.add(cost);        //添加到集合中
            }
        }
        //返回结果
        return Cost;

    }

	public List<Cost> baobiao() {
		// TODO Auto-generated method stub
		return costService.baobiao();
	}

	public List<Cost> yearbaobiao() {
		// TODO Auto-generated method stub
		return costService.yearbaobiao();
	}
}
