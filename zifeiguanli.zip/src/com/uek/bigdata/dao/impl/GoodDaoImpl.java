package com.uek.bigdata.dao.impl;

import com.uek.bigdata.dao.IGoodDao;
import com.uek.bigdata.daomain.Goods;

import java.sql.*;

public class GoodDaoImpl implements IGoodDao {

    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
    @Override
    public void addGood(Goods goods) {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            //Class.forName("com.mysql.cj.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String sql = "insert into t_goods (name,price,stock,category,location,imagePath) values ('" + goods.getName() + "','" + goods.getPrice() + "','" + goods.getStock() + "','" + goods.getCategory() + "','" + goods.getLocation() + "','" + goods.getImagePath() + "')";
            // String sql="UPDATE T_USER SET ADDRESS = ? ,BIRTHDAY = ? , DENTITYCODE = ?, "
            //         + "EMAIL = ?, MOBILE = ?, PASSWORD = ?, SEX = ?,STATUS = ?, TRUENAME = ?,USERNAME = ? WHERE ID = ?";
            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            stmt.executeUpdate(sql);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //8. 释放资源；
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void delproductbyid(String idorname) {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            //Class.forName("com.mysql.cj.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String sql = "delete from t_goods where id = ('"+idorname+"') or name = ('"+idorname+"')";
            // String sql="UPDATE T_USER SET ADDRESS = ? ,BIRTHDAY = ? , DENTITYCODE = ?, "
            //         + "EMAIL = ?, MOBILE = ?, PASSWORD = ?, SEX = ?,STATUS = ?, TRUENAME = ?,USERNAME = ? WHERE ID = ?";
            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            stmt.executeUpdate(sql);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //8. 释放资源；
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

	@Override
	public void modifyGood(Goods goods) {
		// TODO Auto-generated method stub
		try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            //Class.forName("com.mysql.cj.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String sql = "update t_goods set name = ('" + goods.getName() + "'),price = ('" + goods.getPrice() + "')"
            		+ ",sales = ('" + goods.getSales() + "'),stock = ('" + goods.getStock() + "'),category = ('" + goods.getCategory() + "')"
            		+ ",location = ('" + goods.getLocation() + "'),imagePath = ('" + goods.getImagePath() + "') where id = ('"+goods.getId()+"')";
           // String sql="UPDATE T_USER SET ADDRESS = ? ,BIRTHDAY = ? , DENTITYCODE = ?, "
           //         + "EMAIL = ?, MOBILE = ?, PASSWORD = ?, SEX = ?,STATUS = ?, TRUENAME = ?,USERNAME = ? WHERE ID = ?";
            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            stmt.executeUpdate(sql);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //8. 释放资源；
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
	}
}
