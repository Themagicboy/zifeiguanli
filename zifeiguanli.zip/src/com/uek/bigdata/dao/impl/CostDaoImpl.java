package com.uek.bigdata.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.uek.bigdata.dao.ICostDao;
import com.uek.bigdata.daomain.Cost;
import com.uek.bigdata.daomain.Goods;
import com.uek.bigdata.daomain.User;

public class CostDaoImpl implements ICostDao {
	Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
    Cost cost = null;
    List<Cost> list = null;
	public List<Cost> findByUsername(User user) {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            //Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            Class.forName("com.mysql.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String sql = "select t_cost.*,taocanId from t_cost,t_user where userId = '"+user.getUsername()+"' and t_cost.userId=t_user.name";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            rs = stmt.executeQuery(sql);

            //7. 处理结果；
            list = new ArrayList<>();
            while (rs.next()){
                //7.1. 获取数据：
            	String nameString = rs.getString("taocanId");
                String userId = rs.getString("userId");
                String month = rs.getString("month");
                String costprice = rs.getString("costprice");
                //7.2 封装对象：
                cost = new Cost();
                cost.setName(nameString);
                cost.setId(userId);
                cost.setMonth(month);
                cost.setCost(costprice);

                //7.3 添加到数据结构中：
                list.add(cost);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            //8. 释放资源；
            if(rs != null){
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(stmt != null){
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(conn != null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return list;
    }
	@Override
	public List<Cost> selectAll() {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            //Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            Class.forName("com.mysql.cj.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String sql = "select * from t_cost ";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            rs = stmt.executeQuery(sql);

            //7. 处理结果；
            Goods goods = null;
            list = new ArrayList<>();
            while (rs.next()) {
                //7.1. 获取数据：
                String name = rs.getString("userId");
                String month = rs.getString("month");
                String costprice = rs.getString("costprice");

                //7.2 封装对象：
                cost = new Cost();
                cost.setId(name);
                cost.setMonth(month);
                cost.setCost(costprice);

                //7.3 添加到数据结构中：
                list.add(cost);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //8. 释放资源；
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return list;
    }
	@Override
	public List<Cost> baobiao() {
		try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            //Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            Class.forName("com.mysql.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String sql = "select t_cost.month, t_goods.name, sum(t_cost.costprice) as costprice from t_cost, t_goods where t_cost.costprice =t_goods.price GROUP BY month, name";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            rs = stmt.executeQuery(sql);
            
            //7. 处理结果；
            list = new ArrayList<>();
            while (rs.next()){
                //7.1. 获取数据：
              //  String userId = rs.getString("userId");
                String month = rs.getString("month");
                String costprice = rs.getString("costprice");
                String name = rs.getString("name");
                //7.2 封装对象：
                cost = new Cost();
            //    cost.setId(userId);
                cost.setMonth(month);
                cost.setCost(costprice);
                cost.setName(name);

                //7.3 添加到数据结构中：
                list.add(cost);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            //8. 释放资源；
            if(rs != null){
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(stmt != null){
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(conn != null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return list;
	}
	@Override
	public List<Cost> yearbaobiao() {
		try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            //Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            Class.forName("com.mysql.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String sql = "select t_cost.userId, t_goods.name, sum(t_cost.costprice) as costprice from t_cost, t_goods where t_cost.costprice =t_goods.price GROUP BY userId, name";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            rs = stmt.executeQuery(sql);
            
            //7. 处理结果；
            list = new ArrayList<>();
            while (rs.next()){
                //7.1. 获取数据：
                String userId = rs.getString("userId");
               // String month = rs.getString("month");
                String costprice = rs.getString("costprice");
                String name = rs.getString("name");
                //7.2 封装对象：
                cost = new Cost();
                cost.setId(userId);
            //    cost.setMonth(month);
                cost.setCost(costprice);
                cost.setName(name);

                //7.3 添加到数据结构中：
                list.add(cost);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            //8. 释放资源；
            if(rs != null){
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(stmt != null){
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(conn != null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return list;
	}
}
