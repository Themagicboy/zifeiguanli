package com.uek.bigdata.dao.impl;

import com.uek.bigdata.dao.IUserDao;
import com.uek.bigdata.daomain.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 优逸客大数据研发部
 * @className: UserDaoImpl
 * @description: 用户模块Dao层接口实现类
 * @date: 2020/11/26 15:37
 * @version: 1.0
 */
public class UserDaoImpl implements IUserDao {

    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
    List<User> list = null;

    /**
     * @Param user:
     * @return void
     * @description 添加用户
     * @author 优逸客大数据研发部
     * @date 2020/11/27 11:20
     */
    @Override
    public void add(User user) {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            //Class.forName("com.mysql.cj.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String sql = "insert into t_user value ('" + user.getUsername() + "','" + user.getPassword() + "','" + user.getName() + "'" +
                    ",'" + user.getSex() + "','" + user.getAge() + "','" + user.getCity() + "',"+0+")";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            stmt.executeUpdate(sql);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //8. 释放资源；
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @Param :
     * @return java.util.List<com.uek.bigdata.daomain.User>
     * @description 查找所有的用户
     * @author 优逸客大数据研发部
     * @date 2020/11/27 11:20
     */
    @Override
    public List<User> selectAll() {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            //Class.forName("com.mysql.cj.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String sql = "select * from t_user";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            rs = stmt.executeQuery(sql);

            //7. 处理结果；
            User user = null;
            list = new ArrayList<>();
            while (rs.next()) {
                //7.1. 获取数据：
                String username = rs.getString("username");
                String name = rs.getString("name");
                
                String password = rs.getString("password");
                String city = rs.getString("city");
                String sex = rs.getString("sex");
                int age = rs.getInt("age");

                //7.2 封装对象：
                user = new User();
                user.setUsername(username);
                user.setName(name);
                user.setPassword(password);
                user.setSex(sex);
                user.setCity(city);
                user.setAge(age);

                //7.3 添加到数据结构中：
                list.add(user);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //8. 释放资源；
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return list;
    }

    public void UpdatePwd(User user) {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            //Class.forName("com.mysql.cj.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String sql = "update t_user set name = ('" + user.getName() + "'),password = ('" + user.getPassword() + "') where username = ('"+user.getUsername()+"')";
           // String sql="UPDATE T_USER SET ADDRESS = ? ,BIRTHDAY = ? , DENTITYCODE = ?, "
           //         + "EMAIL = ?, MOBILE = ?, PASSWORD = ?, SEX = ?,STATUS = ?, TRUENAME = ?,USERNAME = ? WHERE ID = ?";
            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            stmt.executeUpdate(sql);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //8. 释放资源；
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

	@Override
	public List<User> findUserByUserName(String Name) {
		try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            //Class.forName("com.mysql.cj.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String sql = "select * from t_user where name ="+Name;

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            rs = stmt.executeQuery(sql);

            //7. 处理结果；
            User user = null;
            list = new ArrayList<>();
            while (rs.next()) {
                //7.1. 获取数据：
                String username = rs.getString("username");
                String name = rs.getString("name");
                
                String password = rs.getString("password");
                String city = rs.getString("city");
                String sex = rs.getString("sex");
                if(sex.equals("1")) {
                	sex = "男";
                }else {
                	sex = "女";
				}
                int age = rs.getInt("age");

                //7.2 封装对象：
                user = new User();
                user.setUsername(username);
                user.setName(name);
                user.setPassword(password);
                user.setSex(sex);
                user.setCity(city);
                user.setAge(age);

                //7.3 添加到数据结构中：
                list.add(user);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //8. 释放资源；
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return list;
	}
}
