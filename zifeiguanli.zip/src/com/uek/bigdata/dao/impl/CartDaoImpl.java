package com.uek.bigdata.dao.impl;

import com.uek.bigdata.dao.ICartDao;
import com.uek.bigdata.daomain.CartItem;
import com.uek.bigdata.daomain.User;
import com.uek.bigdata.view.resMonthFrame;

import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * @author 优逸客大数据研发部
 * @className: CartDaoImpl
 * @description: 购物车模块Dao层接口实现类
 * @date: 2020/11/26 15:37
 * @version: 1.0
 */
public class CartDaoImpl implements ICartDao {

    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
    CartItem cartItem = null;
    List<CartItem> list = null;

    /**
     * @Param null:
     * @return
     * @description 查找
     * @author 优逸客大数据研发部
     * @date 2020/11/27 11:13
     */
    @Override
    public CartItem selectItemById(int id) {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            //Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            Class.forName("com.mysql.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String sql = "select * from t_cart where id = '"+id+"'";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            rs = stmt.executeQuery(sql);

            //7. 处理结果；
            while (rs.next()){
                //7.1. 获取数据：
                String name = rs.getString("name");
                int count = rs.getInt("count");
                double price = rs.getDouble("price");
                double totalprice = rs.getDouble("totalprice");

                //7.2 封装对象：
                cartItem = new CartItem();
                cartItem.setId(id);
                cartItem.setName(name);
                cartItem.setCount(count);
                cartItem.setPrice(price);
                cartItem.setTotalPrice(totalprice);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            //8. 释放资源；
            if(rs != null){
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(stmt != null){
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(conn != null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return cartItem;
    }

    /**
     * @Param id:
     * @Param count:
     * @return void
     * @description 添加
     * @author 优逸客大数据研发部
     * @date 2020/11/27 11:17
     */
    @Override
    public void accCount(int id, int count) {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            //Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            Class.forName("com.mysql.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String updateCountSql = "update t_cart set count = '"+cartItem.getCount()+"' + 1 where id = '"+cartItem.getId()+"'";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            stmt.executeUpdate(updateCountSql);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            //8. 释放资源；
            if(stmt != null){
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(conn != null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @Param id:
     * @Param count:
     * @Param price:
     * @return void
     * @description 修改商品数量
     * @author 优逸客大数据研发部
     * @date 2020/11/27 11:17
     */
    @Override
    public void updateTotalPrice(Integer id, Integer count, double price) {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            //Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            Class.forName("com.mysql.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String updateTotalPriceSql = "update t_cart set totalprice = '"+count * price+"' where id = '"+cartItem.getId()+"'";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            stmt.executeUpdate(updateTotalPriceSql);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            //8. 释放资源；
            if(stmt != null){
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(conn != null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @Param cartItem:
     * @return void
     * @description 购物车添加商品
     * @author 优逸客大数据研发部
     * @date 2020/11/27 11:18
     */
    @Override
    public void insertItem(CartItem cartItem) {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            //Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            Class.forName("com.mysql.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String insertSql = "insert into t_cart values('"+cartItem.getUserId()+"' ,'"+cartItem.getId()+"', '"+cartItem.getName()+"' , '"+cartItem.getCount()+"' , '"+cartItem.getPrice()+"' , '"+cartItem.getTotalPrice()+"')";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            stmt.executeUpdate(insertSql);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            //8. 释放资源；
            if(stmt != null){
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(conn != null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @Param id:
     * @return void
     * @description 删除购物车商品
     * @author 优逸客大数据研发部
     * @date 2020/11/27 11:18
     */
    @Override
    public void deleteItem(int id) {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            //Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            Class.forName("com.mysql.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String sql = "delete from t_cart where id = '"+id+"'";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            stmt.executeUpdate(sql);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            //8. 释放资源；
            if(stmt != null){
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(conn != null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @Param :
     * @return void
     * @description 清空购物车
     * @author 优逸客大数据研发部
     * @date 2020/11/27 11:18
     */
    @Override
    public void deleteAll() {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            //Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            Class.forName("com.mysql.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String sql = "delete from t_cart";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            stmt.executeUpdate(sql);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            //8. 释放资源；
            if(stmt != null){
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(conn != null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @Param id:
     * @Param count:
     * @return void
     * @description 修改商品数量
     * @author 优逸客大数据研发部
     * @date 2020/11/27 11:19
     */
    @Override
    public void updateCount(int id, int count) {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            //Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            Class.forName("com.mysql.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String updateCountSql = "update t_cart set count = '"+count+"' where id = '"+id+"'";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            stmt.executeUpdate(updateCountSql);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            //8. 释放资源；
            if(stmt != null){
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(conn != null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @Param :
     * @return java.util.List<com.uek.bigdata.daomain.CartItem>
     * @description 查看所有购物车商品
     * @author 优逸客大数据研发部
     * @date 2020/11/27 11:19
     */
    @Override
    public List<CartItem> selectAll() {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            //Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            Class.forName("com.mysql.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String sql = "select * from t_cart";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            rs = stmt.executeQuery(sql);

            //7. 处理结果；
            list = new ArrayList<>();
            while (rs.next()){
                //7.1. 获取数据：
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int count = rs.getInt("count");
                double price = rs.getDouble("price");
                double totalprice = rs.getDouble("totalprice");

                //7.2 封装对象：
                cartItem = new CartItem();
                cartItem.setId(id);
                cartItem.setName(name);
                cartItem.setCount(count);
                cartItem.setPrice(price);
                cartItem.setTotalPrice(totalprice);

                //7.3 添加到数据结构中：
                list.add(cartItem);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            //8. 释放资源；
            if(rs != null){
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(stmt != null){
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(conn != null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return list;
    }

    /**
     * @Param user:
     * @return java.util.List<com.uek.bigdata.daomain.CartItem>
     * @description 根据用户名查购物车
     * @author 优逸客大数据研发部
     * @date 2020/11/27 11:19
     */
    @Override
    public List<CartItem> findByUsername(User user) {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            //Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            Class.forName("com.mysql.cj.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String sql = "select * from t_cart where userId = '"+user.getUsername()+"'";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            rs = stmt.executeQuery(sql);

            //7. 处理结果；
            list = new ArrayList<>();
            while (rs.next()){
                //7.1. 获取数据：
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int count = rs.getInt("count");
                double price = rs.getDouble("price");
                double totalprice = rs.getDouble("totalprice");

                //7.2 封装对象：
                cartItem = new CartItem();
                cartItem.setId(id);
                cartItem.setName(name);
                cartItem.setCount(count);
                cartItem.setPrice(price);
                cartItem.setTotalPrice(totalprice);

                //7.3 添加到数据结构中：
                list.add(cartItem);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            //8. 释放资源；
            if(rs != null){
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(stmt != null){
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(conn != null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return list;
    }

	@Override
	public void modifyItem(int id) {
		// TODO Auto-generated method stub
		try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            //Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            Class.forName("com.mysql.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String updateCountSql = "";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            stmt.executeUpdate(updateCountSql);
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            //8. 释放资源；
            if(stmt != null){
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if(conn != null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
	}

	@Override
	public void buyItem(String str) {
		// TODO Auto-generated method stub
			try {
	            /**
	             * 采用JDBC的方式，实现程序与MySQL数据库的连接
	             */
	            //1. 引入对应版本的数据库驱动jar包：

	            //2. 注册驱动；
	            //2.1  MySQL8.x之前Driver：
	            //Class.forName("com.mysql.jdbc.Driver");
	            //2.2  MySQL8.x之后Driver：
	            Class.forName("com.mysql.jdbc.Driver");

	            //3. 获取数据库连接对象 Connection；
	            conn = DriverManager.getConnection(
	                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
	                    "root",
	                    "123456"
	            );

	            //4. 定义sql；
	            String sql = "select * from t_cart where name= '"+str+"'";
	            
	   //         String sql = "select * from t_cart where userId = '"+user.getUsername()+"'";

	            //5. 获取执行sql语句的对象 Statement；
	            stmt = conn.createStatement();

	            //6. 执行sql，接受返回结果；
	            rs = stmt.executeQuery(sql);
	        //    int id1 = rs.getInt("id");
	            while(rs.next()) {
		            String nameString = rs.getString("name");
		            int count = rs.getInt("count");
		            double price = rs.getDouble("price");
		            double totalprice = rs.getDouble("totalprice");
		            String userId = rs.getString("userId");
		            CartItem cartItem = new CartItem();
		          //  cartItem.setId(id1);
		            cartItem.setName(nameString);
		            cartItem.setPrice(price);
		            cartItem.setCount(count);
		            cartItem.setTotalPrice(totalprice);
		            //6. 执行sql，接受返回结果；
		            Calendar cal = Calendar.getInstance();
		            int month = cal.get(Calendar.MONTH) + 1;
		            
		            sql = "insert into t_cost values(?,?,?)";
		           // String sql="SELECT * FROM user_login WHERE user_password=? AND (user_name=? OR user_telNumber=?)";
		            PreparedStatement preparedStatement = conn.prepareStatement(sql);
		            preparedStatement.setString(1,userId);
		            preparedStatement.setInt(2, month);
		            preparedStatement.setString(3,String.valueOf(totalprice));
		            int resultSet = preparedStatement.executeUpdate();
		            
	            }
	            
	        } catch (Exception e) {
	            e.printStackTrace();
	        }finally {
	            //8. 释放资源；
	            if(stmt != null){
	                try {
	                    stmt.close();
	                } catch (SQLException e) {
	                    e.printStackTrace();
	                }
	            }

	            if(conn != null){
	                try {
	                    conn.close();
	                } catch (SQLException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	}
}
