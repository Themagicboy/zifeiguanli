package com.uek.bigdata.dao.impl;

import com.uek.bigdata.dao.IBrowseDao;
import com.uek.bigdata.daomain.Goods;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 优逸客大数据研发部
 * @className: BrowseDaoImpl
 * @description: 商品浏览模块Dao层接口实现类
 * @date: 2020/11/26 15:37
 * @version: 1.0
 */
public class BrowseDaoImpl implements IBrowseDao {

    Connection conn = null;
    Statement stmt = null;
    ResultSet rs = null;
    List<Goods> list = null;

    /**
     * @return java.util.List<com.uek.bigdata.daomain.Goods>
     * @Param :
     * @description 查找所有的商品
     * @author 优逸客大数据研发部
     * @date 2020/11/27 11:10
     */
    @Override
    public List<Goods> selectAll() {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            //Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            Class.forName("com.mysql.cj.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String sql = "select * from t_goods";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            rs = stmt.executeQuery(sql);

            //7. 处理结果；
            Goods goods = null;
            list = new ArrayList<>();
            while (rs.next()) {
                //7.1. 获取数据：
                int id = rs.getInt("id");
                String name = rs.getString("name");
                double price = rs.getDouble("price");
                int sales = rs.getInt("sales");
                int stock = rs.getInt("stock");
                String category = rs.getString("category");
                String location = rs.getString("location");
                String imagePath = rs.getString("imagePath");

                //7.2 封装对象：
                goods = new Goods();
                goods.setId(id);
                goods.setName(name);
                goods.setPrice(price);
                goods.setSales(sales);
                goods.setStock(stock);
                goods.setCategory(category);

                goods.setLocation(location);
                goods.setImagePath(imagePath);

                //7.3 添加到数据结构中：
                list.add(goods);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //8. 释放资源；
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return list;
    }

    /**
     * @Param id:
     * @return com.uek.bigdata.daomain.Goods
     * @description 根据id查找商品
     * @author 优逸客大数据研发部
     * @date 2020/11/27 11:11
     */
    @Override
    public Goods findGoodsById(int id) {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            //Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            Class.forName("com.mysql.cj.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String sql = "select * from t_goods where id =  '" + id + "'";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            rs = stmt.executeQuery(sql);

            //7. 处理结果；
            Goods goods = null;
            list = new ArrayList<>();
            while (rs.next()) {
                //7.1. 获取数据：
                String name = rs.getString("name");
                double price = rs.getDouble("price");
                int sales = rs.getInt("sales");
                int stock = rs.getInt("stock");
                String category = rs.getString("category");
                String location = rs.getString("location");
                String imagePath = rs.getString("imagePath");

                //7.2 封装对象：
                goods = new Goods();
                goods.setId(id);
                goods.setName(name);
                goods.setPrice(price);
                goods.setSales(sales);
                goods.setStock(stock);
                goods.setCategory(category);
                goods.setLocation(location);
                goods.setImagePath(imagePath);

                //7.3 添加到数据结构中：
                return goods;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //8. 释放资源；
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return null;
    }

    /**
     * @Param goods:
     * @return void
     * @description 修改商品信息
     * @author 优逸客大数据研发部
     * @date 2020/11/27 11:12
     */
    @Override
    public void updateGoods(Goods goods) {
        try {
            /**
             * 采用JDBC的方式，实现程序与MySQL数据库的连接
             */
            //1. 引入对应版本的数据库驱动jar包：

            //2. 注册驱动；
            //2.1  MySQL8.x之前Driver：
            //Class.forName("com.mysql.jdbc.Driver");
            //2.2  MySQL8.x之后Driver：
            Class.forName("com.mysql.cj.jdbc.Driver");

            //3. 获取数据库连接对象 Connection；
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/zifeiguanli?serverTimezone=UTC&characterEncoding=utf8&useUnicode=true&useSSL=false",
                    "root",
                    "123456"
            );

            //4. 定义sql；
            String updateCountSql = "update t_goods set stock = '" + goods.getStock() + "' , sales = '" + goods.getSales() + "'   where id = '" + goods.getId() + "'";

            //5. 获取执行sql语句的对象 Statement；
            stmt = conn.createStatement();

            //6. 执行sql，接受返回结果；
            stmt.executeUpdate(updateCountSql);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //8. 释放资源；
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
