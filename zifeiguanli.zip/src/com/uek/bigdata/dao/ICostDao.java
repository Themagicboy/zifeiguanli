package com.uek.bigdata.dao;

import java.util.List;

import com.uek.bigdata.daomain.Cost;
import com.uek.bigdata.daomain.User;

public interface ICostDao {

	public List<Cost> selectAll();

	public List<Cost> findByUsername(User user);

	public List<Cost> baobiao();

	public List<Cost> yearbaobiao();

}
