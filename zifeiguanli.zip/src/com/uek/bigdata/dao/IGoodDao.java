package com.uek.bigdata.dao;

import com.uek.bigdata.daomain.Goods;

public interface IGoodDao {
    public void addGood(Goods goods);

    public void delproductbyid(String id);

	public void modifyGood(Goods goods);
}
