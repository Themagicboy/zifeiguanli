package com.uek.bigdata.service.impl;

import java.util.List;

import com.uek.bigdata.dao.ICostDao;
import com.uek.bigdata.dao.IGoodDao;
import com.uek.bigdata.dao.impl.CostDaoImpl;
import com.uek.bigdata.dao.impl.GoodDaoImpl;
import com.uek.bigdata.daomain.Cost;
import com.uek.bigdata.daomain.Goods;
import com.uek.bigdata.daomain.User;
import com.uek.bigdata.service.ICostService;

public class CostServiceImpl implements ICostService{

	ICostDao costDao = new CostDaoImpl();
	
	@Override
	public List<Cost> findByUsername(User user) {
		// TODO Auto-generated method stub
		
		return costDao.findByUsername(user);
	}

	@Override
	public List<Cost> findAll() {
		List<Cost> goods = costDao.selectAll();
        //2. 返回结果
        return goods;
	}

	@Override
	public List<Cost> selectAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cost> baobiao() {
		// TODO Auto-generated method stub
		return costDao.baobiao();
	}

	@Override
	public List<Cost> yearbaobiao() {
		// TODO Auto-generated method stub
		return costDao.yearbaobiao();
	}

}
