package com.uek.bigdata.service.impl;

import com.uek.bigdata.dao.IGoodDao;
import com.uek.bigdata.dao.impl.GoodDaoImpl;
import com.uek.bigdata.daomain.Goods;
import com.uek.bigdata.service.IGoodService;

public class GoodServiceImpl implements IGoodService {
    IGoodDao goodDao = new GoodDaoImpl();

    @Override
    public void addGood(Goods goods) {
        goodDao.addGood(goods);
    }

    @Override
    public void delproductbyid(String id) {
        goodDao.delproductbyid(id);
    }

	@Override
	public void modifyGood(Goods goods) {
		// TODO Auto-generated method stub
		goodDao.modifyGood(goods);
	}


}
