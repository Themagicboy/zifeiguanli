package com.uek.bigdata.service;

import com.uek.bigdata.daomain.Goods;

public interface IGoodService {
    public void addGood(Goods goods);

    public  void delproductbyid(String id);

	public void modifyGood(Goods goods);
}
