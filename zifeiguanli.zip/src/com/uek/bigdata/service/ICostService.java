package com.uek.bigdata.service;

import java.util.List;

import com.uek.bigdata.daomain.Cost;
import com.uek.bigdata.daomain.Goods;
import com.uek.bigdata.daomain.User;

public interface ICostService {

	List<Cost> findByUsername(User user);
	public List<Cost> findAll();
	public List<Cost> selectAll();
	List<Cost> baobiao();
	List<Cost> yearbaobiao();
}
