package com.uek.bigdata.util;

import com.uek.bigdata.view.Browse;

/*
 * @Param null:
 * @return
 * @description 界面工具类
 * @author 优逸客大数据研发部
 * @date 2020/11/27 11:41
 */
public class FrameUtils {

    public static Browse browse;  //给页面加缓存
}
