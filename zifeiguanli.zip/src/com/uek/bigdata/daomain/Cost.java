package com.uek.bigdata.daomain;

public class Cost {
	private String id;
	private String month;
	private String cost;
	private String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getCost() {
		return cost;
	}
	public void setCost(String cost) {
		this.cost = cost;
	}
	@Override
	public String toString() {
		return "Cost [id=" + id + ", month=" + month + ", cost=" + cost + "]";
	}
	
	
}
